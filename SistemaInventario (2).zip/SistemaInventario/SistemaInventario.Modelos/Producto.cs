﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemaInventario.Modelos
{
    public class Producto
    {
        [Key]
        public int Id { get; set; }

        //NumeroSerie
        [Required]
        [MaxLength(30)]
        [Display(Name = "Número de Serie")]
        public string NumeroSerie { get; set; }

        //Descripcion
        [Required]
        [MaxLength(30)]
        [Display(Name = "Descripción")]
        public string Descripcion { get; set; }

        //Precio
        [Required]
        [Range(1, 10000)]
        [Display(Name = "Precio")]
        public double Precio { get; set; }

        //Costo
        [Required]
        [Range(1, 10000)]
        [Display(Name = "Costo")]
        public double Costo { get; set; }

        //Imagen 'URL'
        public string ImagenUrl { get; set; }

        //FOREIGN KEYS
        //CATEGORIA - CategoriaId
        [Required]
        public int CategoriaId { get; set; }

        //CATEGORIA - Categoria
        [ForeignKey("CategoriaId")]
        public Categoria Categoria { get; set; }

        //MARCA - MarcaId
        [Required]
        public int MarcaId { get; set; }

        //MARCA - Marca
        [Required]
        [ForeignKey("MarcaId")]
        public Marca Marca { get; set; }

        //---RECURSIVIDAD---
        public int? PadreId { get; set; }
        public virtual Producto Padre { get; set; }
    }
}
