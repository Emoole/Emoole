﻿using SistemaInventario.AccesoDatos.Data;
using SistemaInventario.AccesoDatos.Repositorio.IRepositorio;
using SistemaInventario.Modelos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemaInventario.AccesoDatos.Repositorio
{
    public class MarcaRepositorio : Repositorio<Marca>, IMarcaRepositorio
    {
        private readonly ApplicationDbContext _db;

        public MarcaRepositorio(ApplicationDbContext db):base(db)
        {
            _db = db;
        }
        public void Actualizar(Marca marca)
        {
            var MarcaDb = _db.Marcas.FirstOrDefault(m=> m.Id==marca.Id);
            if (MarcaDb!=null)
            {
                MarcaDb.Nombre = marca.Nombre;
                MarcaDb.Estado = marca.Estado;

            }
        
        }
    }
}
