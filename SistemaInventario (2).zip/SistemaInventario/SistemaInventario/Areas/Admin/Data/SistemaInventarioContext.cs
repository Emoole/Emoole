﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SistemaInventario.Areas.Admin.Data
{
    public class SistemaInventarioContext:DbContext
    {
        public SistemaInventarioContext(DbContextOptions<SistemaInventarioContext> options)
            : base(options)
        {
        }

        public DbSet<SistemaInventario.Modelos.Bodega> Bodega { get; set; }
    }
}
