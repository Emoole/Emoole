﻿var datatable;

$(document).ready(function () {
    loadDataTable();
});
function loadDataTable() {
    datatableProducto = $("#tbldatos").DataTable({
        "ajax": {
            "url": "/Admin/Producto/ObtenerTodos"
        },
        "columns": [
            { "data": "numeroserie", "width": "20%" },
            { "data": "descripcion", "width": "20%" },
            { "data": "categoria.Nombre", "width": "20%" },
            { "data": "marca.Nombre", "width": "20%" },
            { "data": "precio", "width": "20%" },         
            {
                "data": "id",
                "render": function (data) {
                    return `
                        <div class="text-center" >
                            <a href="/Admin/Producto/UpSert/${data}" class="btn btn-success text-white" style="cursor:pointer">
                                <i class="fas fa-edit"> </i>
                            </a>
                            <a onClick=Delete("/Admin/Producto/Delete/${data}") class="btn btn-danger text-white" style="cursor:pointer">
                                <i class="fas fa-trash"> </i>
                            </a>
                        </div >
                    `;
                }, "width": "20%"

            }
        ]
    });
}
function Delete(url) {
    //console.log("Hola Delete");
    swal({
        title: "Esta seguro de que quiere eliminar El Producto",
        text: "Este registro no se podra recuperar",
        icon: "warning",
        buttons: true,
        dangerMode: true
    }).then((borrar) => {
        if (borrar) {
            $.ajax({
                type: "DELETE",
                url: url,
                success: function (data) {
                    if (data.success) {
                        toastr.success(data.message);
                        datatableProducto.ajax.reload();
                    }
                    else {
                        toastr.error(data.message);
                    }
                }
            });
        }
    });
}